import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';



@Injectable({
  providedIn: 'root',
})
export class GetShopDataService {
  shopDataList:any;
  constructor(private http: HttpClient) {}

  getShopData() {
    this.shopDataList = 
    this.http
      .get('http://localhost:4200/assets/shop-data.json');
   
  }
}
